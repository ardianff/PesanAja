# Projekku
Aplikasi Pemesanan Tiket Menggunakan Java,XML dan Firebase sebagai data centernya, Min SDK 19


Jika ada yg erorr comment


Silahkan download dan share, jangan di perjualbelikan
